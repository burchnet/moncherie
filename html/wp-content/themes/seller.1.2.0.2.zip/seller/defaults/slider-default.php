	<div id="slider-wrapper">
	    <ul class="bxslider">
							<li><a class='slideurl' href='#'><img src='<?php echo get_template_directory_uri()."/defaults/images/dimg9.jpg"; ?>'><div class='slider-caption container'><div class='slider-caption-title'><?php _e('Fully Responsive Design','ih-photographer') ?></div><div class='slider-caption-desc'><?php _e('Resize your Browser and see it in action.','ih-photographer') ?></div></div></a></li>  
							<li><a class='slideurl' href='#'><img src='<?php echo get_template_directory_uri()."/defaults/images/dimg8.jpg"; ?>'><div class='slider-caption container'><div class='slider-caption-title'><?php _e('Fully Responsive','ih-photographer') ?></div><div class='slider-caption-desc'><?php _e('Resize your Browser to see the Effect.','ih-photographer') ?></div></div></a></li> 
	     </ul>   
	</div>